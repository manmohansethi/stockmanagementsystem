package javaExp;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.*;


@WebServlet("/login")
public class loginServerlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
       

    public loginServerlet() 
    {
        super();
    }


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		String username1 = request.getParameter("name");
        String username = username1.replace(" ", "");

	    String password = request.getParameter("password");
		try {
			Class.forName("oracle.jdbc.OracleDriver");
			Connection con= DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","SYSTEM","1143");
	       if(con!=null)
	       {
	    	   System.out.println("true connected");
	       }
	       else
	       {
	    	   System.out.println("false not connected");
	       }
	       Statement st = con.createStatement();
			String query = "SELECT * FROM user_details ";
			
			
			System.out.println(query);

			ResultSet rs = st.executeQuery(query);
			
			int i = 0;
			while(rs.next())
			{
				i = i+1;
				if (rs.getString(3).equals(username)) 
				{
			        if (rs.getString(4).equals(password)) 
			        {
			            System.out.println("You are logged in successfully!");
			            HttpSession session = request.getSession();
		                session.setAttribute("loggedInUser", rs.getString(2));
		                // Set cookie for session tracking
		                Cookie cookie = new Cookie("sessionId", session.getId());
		                cookie.setMaxAge(30 * 24 * 60 * 60); // Cookie persists until browser is closed
		                response.addCookie(cookie);
		                if(username.equals("admin"))
		                	{

			                session.setAttribute("role", "admin");

		                	}
		                else
		                {
			                session.setAttribute("role", "user");

		                }
	                    response.sendRedirect("index.jsp");
	                   

			        }
			        else
			        {
			            System.out.println("Wrong password!");
	                    response.sendRedirect("login.jsp?error=1");
			        }
			    }
			}
			
			if(i == 0)
			{
				System.out.println("Wrong username!");
                response.sendRedirect("login.jsp?usernotexit=1");
			}
			
			rs.close();
			st.close();
			con.close();
			
			}
			
			catch (Exception e)
			{
				System.out.println(e);
				
			}
	    
	}

}
