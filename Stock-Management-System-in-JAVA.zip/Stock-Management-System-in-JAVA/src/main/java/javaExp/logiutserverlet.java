package javaExp;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;


@WebServlet("/logout")
public class logiutserverlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
       

    public logiutserverlet() 
    {
        super();
    }


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		        HttpSession session = request.getSession(false);
		        if (session != null) {
		            session.invalidate();
		        }

		        // Remove the session cookie
		        Cookie[] cookies = request.getCookies();
		        if (cookies != null) {
		            for (Cookie cookie : cookies) {
		                if (cookie.getName().equals("sessionId")) {
		                    cookie.setMaxAge(0);
		                    response.addCookie(cookie);
		                    break;
		                }
		            }
		        }

		        response.sendRedirect("login.jsp");
		    }
	}

