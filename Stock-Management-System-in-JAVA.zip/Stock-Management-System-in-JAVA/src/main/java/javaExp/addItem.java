package javaExp;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


@WebServlet("/additemnew")
public class addItem extends HttpServlet
{
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
    {
        String Iname = request.getParameter("itemname");
        String Qty = request.getParameter("quantity");
        String desc = request.getParameter("description");
       
//        System.out.println(confirmPassword+" "+ password);
            Connection con = null;
            PreparedStatement pst = null;
            try
            {
                Class.forName("oracle.jdbc.OracleDriver");

                con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "SYSTEM", "1143");
                
                Statement st = con.createStatement();
                String queryc = "SELECT * FROM user_details where username = '"+Iname+"'";
                ResultSet rs = st.executeQuery(queryc);
    			
                int i = 0;
    			while(rs.next())
    			{
    				i = i+1;
    			}
    			
    			if (i == 0) 
				{
					String query = "INSERT INTO Item_info (Item_name, Item_Qty, Item_Desc) VALUES(?, ?, ?)";
	                pst = con.prepareStatement(query);

	                pst.setString(1, Iname);
	                pst.setString(2, Qty); 
	                pst.setString(3, desc);

	                int rowsAffected = pst.executeUpdate();

	                if (rowsAffected > 0)
	                {
	                    System.out.println("Data inserted successfully!");
	                    response.sendRedirect("addnew.jsp?successfully=1");
	                }
	                else
	                {
	                    System.out.println("Failed to insert data.");
	                    response.sendRedirect("addnew.jsp");
	                }
			    }
				else
				{	    	                    
					System.out.println("Username exit!");
					response.sendRedirect("signup.jsp?error=1");
				}
            }
            catch (SQLException | ClassNotFoundException e)
            {
                e.printStackTrace(); // Handle any SQL exceptions
            }
            finally
            {

                try
                {
                    con.close();

                    if (pst != null)
                    {
                        pst.close();
                    }
                }
                catch (SQLException e)
                {
                    e.printStackTrace(); // Handle any SQL exceptions
                }
            }
        
    }
}
