package javaExp;


public class abc {
    public static void main(String[] args) {
        String originalString = "      good morning evry one ";
        

        String modifiedString1 = originalString.replace(" ", "");
        System.out.println("Modified String using replace(): " + modifiedString1);
        
     }
}
