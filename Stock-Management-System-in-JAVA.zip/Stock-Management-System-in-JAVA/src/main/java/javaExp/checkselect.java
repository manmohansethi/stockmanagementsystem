package javaExp;

import java.sql.*;

public class checkselect {
	public static void main (String args[])
	{
		try {
			Class.forName("oracle.jdbc.OracleDriver");
			Connection con= DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","SYSTEM","1143");
	       if(con!=null)
	       {
	    	   System.out.println("true connected");
	       }
	       else
	       {
	    	   System.out.println("false not connected");
	       }
	       Statement st = con.createStatement();
			String query = "SELECT * FROM try";
			
			ResultSet rs = st.executeQuery(query);
			while(rs.next())
			{
				System.out.println(rs.getString(1));
			}
			
			rs.close();
			st.close();
			con.close();
			
			}
			
			catch (Exception e)
			{
				System.out.println(e);
				
			}
	}
}
