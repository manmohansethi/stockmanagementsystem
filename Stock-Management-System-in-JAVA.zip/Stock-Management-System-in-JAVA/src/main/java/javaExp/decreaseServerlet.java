package javaExp;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


@WebServlet("/decreaseItem")
public class decreaseServerlet extends HttpServlet
{
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
    {
        String ItemId = request.getParameter("ItemId");
        String ItemQTY = request.getParameter("ItemQTY");

            Connection con = null;
            PreparedStatement pst = null;
            try
            {
                Class.forName("oracle.jdbc.OracleDriver");

                con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "SYSTEM", "1143");
                
                Statement st = con.createStatement();
                String queryc = "SELECT * FROM Item_info where SL_NO = '"+ItemId+"'";
                ResultSet rs = st.executeQuery(queryc);
    			
                int i = 0;
                int Qty = 0;
    			while(rs.next())
    			{
    				i = i+1;
    				Qty = Integer.parseInt(rs.getString(3));
    			}
    			
    			if (i == 0) 
				{
					System.out.println("Item not exit!");

                    System.out.println("Failed to insert data.");
                    response.sendRedirect("decrease.jsp?error=1");
                    

			    }
				else
				{	    	                    	    	                    
						System.out.println("Item exit!");
						
	    			        if ( Qty >= Integer.parseInt(ItemQTY)) 
	    			        {
	    			        	int IntQty = Qty - Integer.parseInt(ItemQTY);
	    			        	String newQty = Integer.toString(IntQty);
	    			        	String finalQuery = "UPDATE Item_info SET ITEM_QTY = '"+ newQty +"' "+" where SL_NO = '"+ItemId+"' ";
	    			        	System.out.println(finalQuery);
	    			        	
	    			 			 st.executeQuery(finalQuery);
		    	                 response.sendRedirect("decrease.jsp?success=1");

	    			 			 
	    			        }
	    			        else
	    			        {
	    			            System.out.println("Item Qty is less then entered!");
		    	                 response.sendRedirect("decrease.jsp?quantityerror=1");
	    			        }
	    				
					}
            }
            catch (SQLException | ClassNotFoundException e)
            {
                e.printStackTrace(); // Handle any SQL exceptions
            }
            finally
            {

                try
                {
                    con.close();

                    if (pst != null)
                    {
                        pst.close();
                    }
                }
                catch (SQLException e)
                {
                    e.printStackTrace(); // Handle any SQL exceptions
                }
            }
        
    }
}
