package javaExp;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date; 

 

@WebServlet("/prag")
public class pragyan extends HttpServlet
{
	private static final long serialVersionUID = 1L;
	
	 private int countWords(String text) {
	        // Simple word counting logic
	        return text.split("\\s+").length;
	    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
    {
        String str = request.getParameter("textstring");

            Connection con = null;
            PreparedStatement pst = null;
            try
            {
            	String date = new SimpleDateFormat("dd-MM-yyyy").format(new Date());


                Class.forName("oracle.jdbc.OracleDriver");

                con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "SYSTEM", "1143");
                
                String query = "INSERT INTO wordcounter(word_count, word_line, word_date, word_time) VALUES(?, ?, ?, ?)";
                pst = con.prepareStatement(query);
                int wordCount = countWords(str);
                String num = String.valueOf(wordCount);
                String timeStamp = new SimpleDateFormat("HH.mm.ss").format(new Date());
                
                if(str.length() >= 50)
                {
                	String stsubstr = str.substring(0,45);
                    pst.setString(2, stsubstr);

                }
                else
                {
                    pst.setString(2,str);
                }
                
                pst.setString(1, num);
                pst.setString(3, date);
                pst.setString(4, timeStamp);
                

                int rowsAffected = pst.executeUpdate();

                if (rowsAffected > 0)
                {
                    System.out.println("Data inserted successfully!");
                    HttpSession session = request.getSession();
	                session.setAttribute("count", num);
                    response.sendRedirect("pragyanDjsp.jsp?succsess");

                }
                else
                {
                    System.out.println("Failed to insert data.");
                    response.sendRedirect("pragyanDjsp.jsp?error=1");
                }
            }
            catch (SQLException | ClassNotFoundException e)
            {
                e.printStackTrace(); // Handle any SQL exceptions
            }
            finally
            {

                try
                {
                    con.close();

                    if (pst != null)
                    {
                        pst.close();
                    }
                }
                catch (SQLException e)
                {
                    e.printStackTrace(); // Handle any SQL exceptions
                }
            }
        
    }
}
