package javaExp;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.Part;


@WebServlet("/UploadServlet")
@MultipartConfig
public class phot extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        
        try {
            Class.forName("oracle.jdbc.OracleDriver");

            Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "SYSTEM", "1143");
            String sql = "INSERT INTO photos (photo) VALUES (?)";
            PreparedStatement statement = conn.prepareStatement(sql);
            
            Part photoPart = request.getPart("photo");
            if (photoPart != null) {
                InputStream inputStream = photoPart.getInputStream();
                statement.setBlob(1, inputStream);
            }

            int rowsInserted = statement.executeUpdate();
            if (rowsInserted > 0) {
                response.sendRedirect("phot.jsp?message=Photo uploaded successfully.");
            } else {
                response.sendRedirect("phot.jsp?message=Failed to upload photo.");
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            response.sendRedirect("phot.jsp?message=Database error: " + ex.getMessage());
        } catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
}
