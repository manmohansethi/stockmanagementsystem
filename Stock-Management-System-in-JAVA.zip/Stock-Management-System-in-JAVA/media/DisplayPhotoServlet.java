package javaExp;

import java.io.IOException;
import java.io.OutputStream;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/DisplayPhotoServlet")
public class DisplayPhotoServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        
        Connection conn = null;
        PreparedStatement statement = null;
        ResultSet rs = null;
        OutputStream out = null;

        try {
        	 Class.forName("oracle.jdbc.OracleDriver");

              conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "SYSTEM", "1143");
                        String sql = "SELECT photo FROM photos WHERE id = ?";
            statement = conn.prepareStatement(sql);
            statement.setInt(1, Integer.parseInt(request.getParameter("photoId"))); // Assuming you pass photoId as a parameter
            
            rs = statement.executeQuery();
            
            if (rs.next()) {
                Blob blob = rs.getBlob("photo");
                    byte[] fileBytes = blob.getBytes(1, (int) blob.length());

                    out = response.getOutputStream();
                    out.write(fileBytes);
                } else {
                    response.getWriter().write("File not found");
                }
        } catch (SQLException ex) {
            ex.printStackTrace();
            response.getWriter().write("Database error: " + ex.getMessage());
        } catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
            if (out != null) {
                out.close();
            }
            // Close the ResultSet, Statement, and Connection
            // Add proper exception handling for closing resources
            try {
                if (rs != null) {
                    rs.close();
                }
                if (statement != null) {
                    statement.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
